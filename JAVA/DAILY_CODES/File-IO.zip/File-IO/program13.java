import java.io.*;

class Test {

	public static void main(String[] rag) throws IOException {

		Object o = new File("ABC.txt");
		f1.createNewFile();


		File f2 = new File("XYZ.txt");
		f2.createNewFile();

		
		System.out.println(f1.compareTo(f2));

	}
}
		


