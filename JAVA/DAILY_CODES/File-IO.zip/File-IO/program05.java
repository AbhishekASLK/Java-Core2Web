
import java.io.*;

class Test {

	public static void main(String[] args){
	
		File f = new File("/home/abhishekaslk/Desktop/PROJECTS/Core2Web/Java/Java-Core2Web/JAVA/DAILY_CODES/File-IO/abhishek.txt");
		System.out.println(f.getParent());
	}
}
