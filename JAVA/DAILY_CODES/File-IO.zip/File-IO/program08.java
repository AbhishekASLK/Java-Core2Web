import java.io.*;

class Test {
	
	public static void main(String[] args){

		File f = new File("IRONMAN","SPIDERMAN");
		System.out.println(f.mkdirs());
	}
}
