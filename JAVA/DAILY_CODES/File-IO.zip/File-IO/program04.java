
import java.io.*;

class Test {

	public static void main(String[] args){
	
		File f = new File("program04.java");
		System.out.println(f.length());
	}
}
